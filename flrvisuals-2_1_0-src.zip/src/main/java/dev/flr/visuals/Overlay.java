package dev.flr.visuals;

import java.util.Random;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Собственные частицы поверх экрана (без ванильных частиц): снежинки, дождь, лепестки, пепел, звёзды и кубы. */
final class Overlay {
    static final Overlay HUD = new Overlay(240), MENU_A = new Overlay(110), MENU_B = new Overlay(40);

    private final int max;
    private final float[] x, y, d, p;
    private final Random rnd = new Random(11);
    private long last;

    private Overlay(int max) {
        this.max = max;
        x = new float[max]; y = new float[max]; d = new float[max]; p = new float[max];
        for (int i = 0; i < max; i++) {
            x[i] = rnd.nextFloat(); y[i] = rnd.nextFloat(); d[i] = 0.25f + rnd.nextFloat() * 0.75f; p[i] = rnd.nextFloat() * 6.28f;
        }
    }

    /** mode: 1 снег, 2 дождь, 3 лепестки, 4 пепел, 5 звёзды, 6 кубы. */
    void draw(GuiGraphics g, int w, int h, int mode, float amount, float alpha) {
        if (mode <= 0 || alpha <= 0.01f) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.1f, (now - last) / 1e9f);
        if (dt < 0.0005f) dt = 0f;
        last = now;
        float t = (now / 1_000_000_000L % 100000L) + (now % 1_000_000_000L) / 1e9f;
        int n = Math.min(max, 10 + (int) (Mth.clamp(amount, 0f, 1f) * (max - 10)));
        int acc = Config.color() & 0xFFFFFF;
        for (int i = 0; i < n; i++) {
            float dd = d[i], vx, vy;
            switch (mode) {
                case 1 -> { vy = 0.045f + 0.07f * dd; vx = Mth.sin(t * 0.7f + p[i]) * 0.012f; }
                case 2 -> { vy = 0.9f + 0.5f * dd; vx = -0.09f; }
                case 3 -> { vy = 0.06f + 0.04f * dd; vx = Mth.sin(t * 0.9f + p[i]) * 0.03f; }
                case 4 -> { vy = 0.03f + 0.03f * dd; vx = Mth.sin(t + p[i]) * 0.01f; }
                case 5 -> { vy = -0.004f; vx = 0.002f; }
                default -> { vy = 0.025f + 0.03f * dd; vx = Mth.sin(t * 0.4f + p[i]) * 0.01f; }
            }
            x[i] += vx * dt;
            y[i] += vy * dt;
            if (y[i] > 1.08f) { y[i] = -0.08f; x[i] = rnd.nextFloat(); }
            if (y[i] < -0.1f) y[i] = 1.08f;
            if (x[i] < -0.05f) x[i] += 1.1f;
            if (x[i] > 1.05f) x[i] -= 1.1f;
            int px = (int) (x[i] * w), py = (int) (y[i] * h);
            float a = alpha * (0.3f + 0.6f * dd);
            switch (mode) {
                case 1 -> flake(g, px, py, 2 + (int) (dd * 6), 0xFFFFFF, a);
                case 2 -> rain(g, px, py, 5 + (int) (dd * 9), 0xAEC9FF, a * 0.8f);
                case 3 -> petal(g, px, py, 3 + (int) (dd * 3), p[i] > 3.1f ? 0xFFB7D5 : 0xFF8FBF, a);
                case 4 -> { int s = 1 + (int) (dd * 2); g.fill(px, py, px + s, py + s, Ui.argb(0xA6A6B2, a * (0.6f + 0.4f * Mth.sin(t * 3f + p[i])))); }
                case 5 -> star(g, px, py, 2 + (int) (dd * 4), (i % 4 == 0) ? acc : 0xFFFFFF, a * (0.35f + 0.65f * (float) Math.pow(0.5 + 0.5 * Mth.sin(t * 1.8f + p[i] * 3f), 2)));
                default -> cube(g, px, py, 3 + (int) (dd * 5), acc, a * 0.7f);
            }
        }
    }

    private static void flake(GuiGraphics g, int x, int y, int s, int rgb, float a) {
        int col = Ui.argb(rgb, a), r = s / 2;
        g.fill(x - r, y, x + r + 1, y + 1, col);
        g.fill(x, y - r, x + 1, y + r + 1, col);
        if (s >= 5) {
            for (int k = 1; k <= r - 1; k++) {
                g.fill(x + k, y + k, x + k + 1, y + k + 1, col); g.fill(x - k, y + k, x - k + 1, y + k + 1, col);
                g.fill(x + k, y - k, x + k + 1, y - k + 1, col); g.fill(x - k, y - k, x - k + 1, y - k + 1, col);
            }
        }
        if (s >= 7) CosmeticsScreen.rrect(g, x - r - 1, y - r - 1, 2 * r + 3, 2 * r + 3, r + 1, Ui.argb(rgb, a * 0.12f));
    }

    private static void rain(GuiGraphics g, int x, int y, int len, int rgb, float a) {
        int col = Ui.argb(rgb, a);
        for (int k = 0; k < 3; k++) g.fill(x - k, y + k * len / 3, x - k + 1, y + (k + 1) * len / 3, col);
    }

    private static void petal(GuiGraphics g, int x, int y, int s, int rgb, float a) {
        g.fill(x, y, x + s, y + s - 1, Ui.argb(rgb, a));
        g.fill(x + 1, y + 1, x + s + 1, y + s, Ui.argb(rgb, a * 0.7f));
    }

    private static void star(GuiGraphics g, int x, int y, int s, int rgb, float a) {
        int col = Ui.argb(rgb, a), r = s / 2;
        g.fill(x - r, y, x + r + 1, y + 1, col);
        g.fill(x, y - r, x + 1, y + r + 1, col);
        g.fill(x, y, x + 1, y + 1, Ui.argb(0xFFFFFF, Math.min(1f, a * 1.4f)));
    }

    /** Изометрический кубик из трёх граней. */
    private static void cube(GuiGraphics g, int cx, int cy, int s, int rgb, float a) {
        int top = Ui.argb(mul(rgb, 1.0f), a), left = Ui.argb(mul(rgb, 0.5f), a), right = Ui.argb(mul(rgb, 0.72f), a);
        int b = Math.max(1, s / 2);
        for (int xi = -s; xi < s; xi++) {
            int yb = (int) (b * (1f - Math.abs(xi + 0.5f) / s));
            g.fill(cx + xi, cy - yb, cx + xi + 1, cy + yb + 1, top);
            g.fill(cx + xi, cy + yb + 1, cx + xi + 1, cy + yb + 1 + s, xi < 0 ? left : right);
        }
    }

    private static int mul(int rgb, float k) {
        int r = Math.min(255, (int) ((rgb >> 16 & 255) * k + 40 * k)), gg = Math.min(255, (int) ((rgb >> 8 & 255) * k + 40 * k)), b = Math.min(255, (int) ((rgb & 255) * k + 40 * k));
        return r << 16 | gg << 8 | b;
    }
}
