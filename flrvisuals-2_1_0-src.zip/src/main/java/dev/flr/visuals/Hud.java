package dev.flr.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Набор информационных HUD-виджетов в стиле FLR: водяной знак, цель, эффекты, броня,
 * клавиши, перезарядки и счётчик предметов. Только отображение, ничего не влияет на игру.
 */
final class Hud {
    private static final int ROW = 16;
    private static final Item[] CD_ITEMS = {Items.ENDER_PEARL, Items.CHORUS_FRUIT, Items.GOLDEN_APPLE,
            Items.ENCHANTED_GOLDEN_APPLE, Items.SHIELD, Items.FIREWORK_ROCKET, Items.TRIDENT, Items.WIND_CHARGE};
    private static final Item[] COUNT_ITEMS = {Items.TOTEM_OF_UNDYING, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE,
            Items.ENDER_PEARL, Items.EXPERIENCE_BOTTLE, Items.FIREWORK_ROCKET};
    private static ItemStack[] cdStacks, countStacks;

    private static LivingEntity tgt;
    private static long tgtSeen;
    private static float tgtFade, tgtHp = -1f;

    private Hud() {}

    static void render(GuiGraphics g, float pt) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        int acc = Config.color() & 0xFFFFFF;
        int w = g.guiWidth(), h = g.guiHeight();
        if (Config.hudWatermark) watermark(g, mc, p, acc, w);
        if (Config.hudPotions) potions(g, p, acc, 4, 52);
        int ry = Config.hudWatermark ? 30 : 6;
        if (Config.hudHotkeys) ry = hotkeys(g, acc, w, ry);
        if (Config.hudCooldowns) ry = cooldowns(g, p, acc, w, ry, pt);
        if (Config.hudItems) items(g, p, acc, w, ry);
        if (Config.hudArmor) armor(g, p, acc, w, h);
        if (Config.hudTarget) target(g, mc, acc, w, h);
    }

    private static void panel(GuiGraphics g, int x, int y, int w, int h, int acc, float a) {
        int bg = Math.max(8, Math.min(255, (int) (Config.hudAlpha * 235 * a)));
        CosmeticsScreen.rrect(g, x - 1, y - 1, w + 2, h + 2, 9, Ui.argb(acc, 0.3f * a));
        CosmeticsScreen.rrect(g, x, y, w, h, 8, (bg << 24) | 0x0E1019);
    }

    private static void watermark(GuiGraphics g, Minecraft mc, LocalPlayer p, int acc, int sw) {
        String ping = "";
        var conn = mc.getConnection();
        if (conn != null) {
            var pi = conn.getPlayerInfo(p.getUUID());
            if (pi != null) ping = "  |  " + pi.getLatency() + " ms";
        }
        String s = "FLR Visuals  |  " + mc.getUser().getName() + "  |  " + Config.fps + " FPS" + ping;
        int w = Ui.w(s) + 34, h = 20, x = sw - w - 4, y = 4;
        panel(g, x, y, w, h, acc, 1f);
        Ui.logo(g, x + 6, y + 3, 14, 1f);
        Ui.text(g, s, x + 26, y + 6, 0xFFFFFFFF);
    }

    private static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 1 && n <= 10 ? r[n] : String.valueOf(n);
    }

    private static String time(int ticks) {
        int s = Math.max(0, ticks / 20);
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    private static void potions(GuiGraphics g, LocalPlayer p, int acc, int x, int y) {
        List<MobEffectInstance> l = new ArrayList<>(p.getActiveEffects());
        if (l.isEmpty()) return;
        l.sort((a, b) -> Integer.compare(b.getDuration(), a.getDuration()));
        int w = 132, h = 22 + l.size() * ROW;
        panel(g, x, y, w, h, acc, 1f);
        Ui.bold(g, Tr.tr("Effects"), x + 8, y + 6, 0xFFFFFFFF);
        int cy = y + 20;
        for (MobEffectInstance e : l) {
            String name = e.getEffect().value().getDisplayName().getString();
            if (e.getAmplifier() > 0) name += " " + roman(e.getAmplifier() + 1);
            int col = e.getEffect().value().getColor() & 0xFFFFFF;
            CosmeticsScreen.rrect(g, x + 8, cy + 4, 6, 6, 3, 0xFF000000 | col);
            Ui.text(g, Ui.fit(name, w - 74), x + 20, cy + 3, 0xFFFFFFFF);
            boolean inf = e.isInfiniteDuration();
            String t = inf ? "--" : time(e.getDuration());
            boolean low = !inf && e.getDuration() < 200;
            Ui.text(g, t, x + w - 8 - Ui.w(t), cy + 3, low ? 0xFFFF6B6B : 0xFFB8BCD0);
            cy += ROW;
        }
    }

    private static int hotkeys(GuiGraphics g, int acc, int sw, int y) {
        KeyMapping[] ks = {FlrKeys.MENU, FlrKeys.MASTER, FlrKeys.AUTOSWAP, FlrKeys.SOUND, FlrKeys.ZOOM};
        String[] nm = {"Menu", "Master switch", "Auto Swap", "Sound", "Zoom"};
        int[] st = {-1, Config.master ? 1 : 0, Config.autoSwap ? 1 : 0, -1, -1};
        int n = 0;
        for (KeyMapping k : ks) if (!k.isUnbound()) n++;
        if (n == 0) return y;
        int w = 128, h = 22 + n * ROW, x = sw - w - 4;
        panel(g, x, y, w, h, acc, 1f);
        Ui.bold(g, Tr.tr("Hotkeys"), x + 8, y + 6, 0xFFFFFFFF);
        int cy = y + 20;
        for (int i = 0; i < ks.length; i++) {
            if (ks[i].isUnbound()) continue;
            if (st[i] >= 0) CosmeticsScreen.rrect(g, x + 8, cy + 4, 6, 6, 3, st[i] == 1 ? 0xFF58E08A : 0xFF6A6D80);
            Ui.text(g, Tr.tr(nm[i]), x + (st[i] >= 0 ? 20 : 8), cy + 3, 0xFFFFFFFF);
            String key = ks[i].getTranslatedKeyMessage().getString();
            int kw = Ui.w(key) + 10;
            CosmeticsScreen.rrect(g, x + w - 8 - kw, cy + 1, kw, 13, 6, Ui.argb(acc, 0.35f));
            Ui.text(g, key, x + w - 8 - kw + 5, cy + 3, 0xFFFFFFFF);
            cy += ROW;
        }
        return y + h + 4;
    }

    private static int cooldowns(GuiGraphics g, LocalPlayer p, int acc, int sw, int y, float pt) {
        if (cdStacks == null) {
            cdStacks = new ItemStack[CD_ITEMS.length];
            for (int i = 0; i < CD_ITEMS.length; i++) cdStacks[i] = new ItemStack(CD_ITEMS[i]);
        }
        float[] pc = new float[CD_ITEMS.length];
        int n = 0;
        for (int i = 0; i < CD_ITEMS.length; i++) {
            pc[i] = p.getCooldowns().getCooldownPercent(CD_ITEMS[i], pt);
            if (pc[i] > 0f) n++;
        }
        if (n == 0) return y;
        int w = 128, h = 22 + n * 20, x = sw - w - 4;
        panel(g, x, y, w, h, acc, 1f);
        Ui.bold(g, Tr.tr("Cooldowns"), x + 8, y + 6, 0xFFFFFFFF);
        int cy = y + 20;
        for (int i = 0; i < CD_ITEMS.length; i++) {
            if (pc[i] <= 0f) continue;
            g.renderItem(cdStacks[i], x + 6, cy);
            int bx = x + 28, bw = w - 38;
            Ui.text(g, Ui.fit(cdStacks[i].getHoverName().getString(), bw), bx, cy, 0xFFFFFFFF);
            CosmeticsScreen.rrect(g, bx, cy + 11, bw, 4, 2, 0x33FFFFFF);
            int fw = Math.round(bw * Math.min(1f, pc[i]));
            if (fw > 0) CosmeticsScreen.rrect(g, bx, cy + 11, Math.max(4, fw), 4, 2, 0xFF000000 | acc);
            cy += 20;
        }
        return y + h + 4;
    }

    private static int count(LocalPlayer p, Item it) {
        int n = 0;
        for (ItemStack s : p.getInventory().items) if (s.is(it)) n += s.getCount();
        for (ItemStack s : p.getInventory().offhand) if (s.is(it)) n += s.getCount();
        return n;
    }

    private static void items(GuiGraphics g, LocalPlayer p, int acc, int sw, int y) {
        if (countStacks == null) {
            countStacks = new ItemStack[COUNT_ITEMS.length];
            for (int i = 0; i < COUNT_ITEMS.length; i++) countStacks[i] = new ItemStack(COUNT_ITEMS[i]);
        }
        int[] c = new int[COUNT_ITEMS.length];
        int n = 0;
        for (int i = 0; i < COUNT_ITEMS.length; i++) {
            c[i] = count(p, COUNT_ITEMS[i]);
            if (c[i] > 0) n++;
        }
        if (n == 0) return;
        int w = 128, h = 22 + n * 18, x = sw - w - 4;
        panel(g, x, y, w, h, acc, 1f);
        Ui.bold(g, Tr.tr("Items"), x + 8, y + 6, 0xFFFFFFFF);
        int cy = y + 20;
        for (int i = 0; i < COUNT_ITEMS.length; i++) {
            if (c[i] <= 0) continue;
            g.renderItem(countStacks[i], x + 6, cy);
            Ui.text(g, Ui.fit(countStacks[i].getHoverName().getString(), w - 58), x + 28, cy + 4, 0xFFFFFFFF);
            String cs = "x" + c[i];
            Ui.text(g, cs, x + w - 8 - Ui.w(cs), cy + 4, 0xFFB8BCD0);
            cy += 18;
        }
    }

    private static void armor(GuiGraphics g, LocalPlayer p, int acc, int sw, int sh) {
        EquipmentSlot[] sl = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int n = 0;
        for (EquipmentSlot s : sl) if (!p.getItemBySlot(s).isEmpty()) n++;
        if (n == 0) return;
        int w = n * 22 + 8, h = 34, x = sw / 2 + 100, y = sh - 40;
        panel(g, x, y, w, h, acc, 1f);
        int ix = x + 6;
        for (EquipmentSlot s : sl) {
            ItemStack st = p.getItemBySlot(s);
            if (st.isEmpty()) continue;
            g.renderItem(st, ix, y + 4);
            g.renderItemDecorations(Ui.font(), st, ix, y + 4);
            if (st.isDamageableItem() && st.getMaxDamage() > 0) {
                int pct = 100 - st.getDamageValue() * 100 / st.getMaxDamage();
                Ui.scaled(g, pct + "%", ix + 1, y + 22, 0.75f, pct <= Config.armorPercent ? 0xFFFF6B6B : 0xFFFFFFFF, false);
            }
            ix += 22;
        }
    }

    private static void target(GuiGraphics g, Minecraft mc, int acc, int sw, int sh) {
        long now = System.currentTimeMillis();
        Entity e = mc.crosshairPickEntity;
        if (e instanceof LivingEntity le && le != mc.player && le.isAlive()) {
            if (tgt != le) tgtHp = le.getHealth();
            tgt = le;
            tgtSeen = now;
        }
        boolean show = tgt != null && tgt.isAlive() && now - tgtSeen < 2500L;
        tgtFade += ((show ? 1f : 0f) - tgtFade) * 0.2f;
        if (!show && tgtFade < 0.03f) {
            tgt = null;
            tgtFade = 0f;
            return;
        }
        if (tgt == null) return;
        float a = Math.min(1f, tgtFade);
        int w = 152, h = 46, x = sw / 2 + 28, y = sh / 2 + 10;
        panel(g, x, y, w, h, acc, a);
        int fx = x + 8, fy = y + 9;
        if (tgt instanceof AbstractClientPlayer ap) {
            ResourceLocation skin = ap.getSkin().texture();
            RenderSystem.enableBlend();
            g.setColor(1f, 1f, 1f, a);
            g.blit(skin, fx, fy, 28, 28, 8f, 8f, 8, 8, 64, 64);
            g.blit(skin, fx, fy, 28, 28, 40f, 8f, 8, 8, 64, 64);
            g.setColor(1f, 1f, 1f, 1f);
        } else {
            Ui.logo(g, fx, fy, 28, a);
        }
        Ui.bold(g, Ui.fit(tgt.getName().getString(), w - 56), x + 42, y + 8, Ui.argb(0xFFFFFF, a));
        float max = Math.max(1f, tgt.getMaxHealth()), hp = Math.max(0f, tgt.getHealth());
        tgtHp += (hp - tgtHp) * 0.12f;
        int bx = x + 42, by = y + 22, bw = w - 52;
        CosmeticsScreen.rrect(g, bx, by, bw, 6, 3, Ui.argb(0xFFFFFF, 0.18f * a));
        int fw = Math.round(bw * Math.max(0f, Math.min(1f, tgtHp / max)));
        if (fw > 0) CosmeticsScreen.rrect(g, bx, by, Math.max(fw, 6), 6, 3, Ui.argb(acc, a));
        String hs = String.format(Locale.ROOT, "%.1f / %.0f", hp, max);
        Ui.text(g, hs, bx, by + 10, Ui.argb(0xB8BCD0, a));
    }
}
