package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Чёрный фон с шёлковыми волнами (как XMB на PS3), лучом, звёздами и кубами; экран загрузки с логотипом. */
final class Backdrop {
    private static final String[] TIPS = {
            "Press the menu key to open FLR settings.", "Pets look where you look.",
            "Try the Snow weather in the Atmosphere tab.", "Target ESP shows a rotating reticle on your target.",
            "Right-click a feature to open its settings.", "Black and white are available in every colour list."};

    private Backdrop() {}

    static void draw(GuiGraphics g, int w, int h) {
        float t = (System.currentTimeMillis() % 1_000_000L) / 1000f;
        int acc = Config.color() & 0xFFFFFF;
        g.fill(0, 0, w, h, 0xFF040409);
        g.fillGradient(0, h / 2, w, h, 0x00000000, 0x38000000 | acc);

        int beamH = (int) (h * 0.85f);
        for (int y = 0; y < beamH; y += 3) {
            float f = y / (float) beamH;
            int x0 = (int) (w * 0.03f + y * 0.32f), bw = (int) (w * 0.03f + f * w * 0.22f), a = (int) (36 * (1f - f));
            g.fill(x0, y, x0 + bw, y + 3, (a << 24) | acc);
            g.fill(x0 + bw / 3, y, x0 + bw * 2 / 3, y + 3, ((int) (a * 0.7f) << 24) | 0xFFFFFF);
        }
        Overlay.MENU_A.draw(g, w, h, 5, 0.6f, 0.9f);
        int bm = Config.weather == 0 || Config.weather == 5 ? 6 : Config.weather;
        Overlay.MENU_B.draw(g, w, h, bm, 0.35f, 0.7f);

        for (int r = 0; r < 4; r++) {
            float ph = r * 1.7f, base = h * (0.52f + 0.07f * r), amp = h * (0.055f + 0.012f * r);
            int ca = r % 2 == 0 ? 0xFFFFFF : acc;
            for (int x = 0; x < w; x += 4) {
                float yc = base + amp * (float) Math.sin(x * 0.0055f + t * 0.45f + ph)
                        + amp * 0.5f * (float) Math.sin(x * 0.012f - t * 0.3f + ph * 2f);
                float th = h * (0.012f + 0.03f * (0.5f + 0.5f * (float) Math.sin(x * 0.004f + t * 0.2f + ph)));
                g.fill(x, (int) (yc - th), x + 4, (int) (yc + th), 0x10000000 | ca);
                g.fill(x, (int) (yc - th * 0.55f), x + 4, (int) (yc + th * 0.55f), 0x1A000000 | ca);
                g.fill(x, (int) (yc - th * 0.14f), x + 4, (int) (yc + th * 0.14f) + 1, 0x40000000 | ca);
            }
        }
        g.fillGradient(0, 0, w, h / 4, 0xFF040409, 0x00040409);
    }

    /** Экран загрузки: логотип в кольце из точек, заголовок, бегущая полоска и совет. */
    static void loading(GuiGraphics g, int w, int h, String title) {
        long ms = System.currentTimeMillis();
        int cx = w / 2, cy = h / 2 - 22, acc = Config.color() & 0xFFFFFF;
        float pulse = 1f + 0.04f * Mth.sin(ms / 300f);
        int ls = (int) (52 * pulse);
        Ui.logo(g, cx - ls / 2, cy - ls / 2, ls, 1f);
        int head = (int) ((ms / 90) % 16);
        for (int i = 0; i < 16; i++) {
            double ang = i * Math.PI * 2 / 16;
            int d = (head - i + 16) % 16, a = Math.max(40, 255 - d * 15);
            int x = cx + (int) Math.round(Math.cos(ang) * 40), y = cy + (int) Math.round(Math.sin(ang) * 40);
            CosmeticsScreen.rrect(g, x - 2, y - 2, 4, 4, 2, (a << 24) | acc);
        }
        String s = Tr.tr(title);
        Ui.scaled(g, s, cx - Ui.wb(s) * 0.7f, cy + 56, 1.4f, 0xFFFFFFFF, true);
        int bw = 150, bx = cx - bw / 2, by = cy + 82, seg = 46;
        CosmeticsScreen.rrect(g, bx, by, bw, 4, 2, 0x33FFFFFF);
        int sx = bx + (int) ((bw + seg) * ((ms % 1600) / 1600f)) - seg;
        int x0 = Math.max(bx, sx), x1 = Math.min(bx + bw, sx + seg);
        if (x1 > x0) CosmeticsScreen.rrect(g, x0, by, x1 - x0, 4, 2, 0xFF000000 | acc);
        String tip = Tr.tr(TIPS[(int) ((ms / 5000) % TIPS.length)]);
        Ui.center(g, tip, cx, h - 26, 0x99FFFFFF);
        Ui.center(g, "FLR Visuals", cx, h - 14, 0x55FFFFFF);
    }
}
