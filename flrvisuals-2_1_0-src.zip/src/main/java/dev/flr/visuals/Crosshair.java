package dev.flr.visuals;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;

/** Свой прицел вместо ванильного: точка, кольцо, плюс или логотип кролика. Краснеет при наведении на существо. */
final class Crosshair {
    private static float gap, hit;

    private Crosshair() {}

    static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.getCameraType() != CameraType.FIRST_PERSON) return;
        int cx = g.guiWidth() / 2, cy = g.guiHeight() / 2;
        boolean over = mc.crosshairPickEntity instanceof LivingEntity;
        hit += ((over ? 1f : 0f) - hit) * 0.25f;
        gap += ((mc.options.keyAttack.isDown() ? 2.5f : 0f) - gap) * 0.3f;
        int base = Config.color() & 0xFFFFFF;
        int rgb = ((int) (((base >> 16) & 255) * (1 - hit) + 255 * hit) << 16) | ((int) (((base >> 8) & 255) * (1 - hit) + 77 * hit) << 8)
                | (int) ((base & 255) * (1 - hit) + 94 * hit);
        int col = 0xFF000000 | rgb, dark = 0xB0000000;
        switch (Config.crosshair) {
            case 1 -> {
                CosmeticsScreen.rrect(g, cx - 3, cy - 3, 6, 6, 3, dark);
                CosmeticsScreen.rrect(g, cx - 2, cy - 2, 4, 4, 2, col);
            }
            case 2 -> {
                float r = 6f + gap;
                for (int i = 0; i < 16; i++) {
                    double a = i * Math.PI * 2 / 16;
                    int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
                    g.fill(x - 1, y - 1, x + 1, y + 1, dark);
                    g.fill(x, y, x + 1, y + 1, col);
                }
                g.fill(cx, cy, cx + 1, cy + 1, col);
            }
            case 3 -> {
                int o = 3 + (int) gap, l = 5;
                for (int s = 0; s < 4; s++) {
                    int dx = s == 0 ? -1 : s == 1 ? 1 : 0, dy = s == 2 ? -1 : s == 3 ? 1 : 0;
                    int x0 = cx + dx * o, y0 = cy + dy * o, x1 = cx + dx * (o + l), y1 = cy + dy * (o + l);
                    g.fill(Math.min(x0, x1) - 1, Math.min(y0, y1) - 1, Math.max(x0, x1) + 2, Math.max(y0, y1) + 2, dark);
                    g.fill(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1) + 1, Math.max(y0, y1) + 1, col);
                }
            }
            case 4 -> {
                int s = 14 + (int) (gap * 2);
                Ui.logo(g, cx - s / 2, cy - s / 2, s, 0.55f + 0.45f * hit);
                g.fill(cx, cy, cx + 1, cy + 1, col);
            }
            default -> { }
        }
    }
}
