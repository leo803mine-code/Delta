package dev.flr.visuals;

import java.util.ArrayDeque;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Скруглённая плашка-уведомление над хотбаром (броня, Auto Swap) или стопка плашек справа внизу. */
public final class Notify {
    private record Msg(String text, int color, long start) {}

    private static final long LIFE = 3200L;
    private static Msg cur;
    private static final ArrayDeque<Msg> STACK = new ArrayDeque<>();

    private Notify() {}

    public static void show(String text, int rgb) {
        Msg m = new Msg(text, rgb & 0xFFFFFF, System.currentTimeMillis());
        if (Config.notifyStack) {
            STACK.addFirst(m);
            while (STACK.size() > 4) STACK.removeLast();
        } else {
            cur = m;
        }
    }

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;
        if (Config.notifyStack) {
            stack(g);
            return;
        }
        Msg m = cur;
        if (m == null) return;
        long age = System.currentTimeMillis() - m.start;
        if (age > LIFE) { cur = null; return; }
        float in = Math.min(1f, age / 260f), out = Math.min(1f, (LIFE - age) / 450f);
        float a = Math.min(in, out);
        if (a < 0.03f) return;
        int w = Ui.w(m.text) + 36, h = 22;
        int x = (g.guiWidth() - w) / 2, y = g.guiHeight() - 66 + (int) ((1f - in) * 12f);
        draw(g, m, x, y, w, h, a);
    }

    private static void stack(GuiGraphics g) {
        long now = System.currentTimeMillis();
        STACK.removeIf(m -> now - m.start() > LIFE);
        int i = 0;
        for (Msg m : STACK) {
            long age = now - m.start();
            float in = Math.min(1f, age / 260f), out = Math.min(1f, (LIFE - age) / 450f);
            float a = Math.min(in, out);
            int w = Ui.w(m.text()) + 36, h = 22;
            if (a >= 0.03f) {
                int x = g.guiWidth() - w - 6 + (int) ((1f - in) * 30f);
                int y = g.guiHeight() - 34 - i * (h + 4);
                draw(g, m, x, y, w, h, a);
            }
            i++;
        }
    }

    private static void draw(GuiGraphics g, Msg m, int x, int y, int w, int h, float a) {
        int c = m.color;
        CosmeticsScreen.rrect(g, x - 1, y - 1, w + 2, h + 2, 12, ((int) (a * 110) << 24) | c);
        CosmeticsScreen.rrect(g, x, y, w, h, 11, ((int) (a * 236) << 24) | 0x11121B);
        Ui.logo(g, x + 6, y + 4, 14, a);
        Ui.text(g, m.text, x + 24, y + 7, ((Math.max(8, (int) (a * 255))) << 24) | 0xFFFFFF, false);
    }
}
