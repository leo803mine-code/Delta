package dev.flr.visuals;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.client.gui.ModListScreen;

/** Главное меню FLR: ряд иконок в стиле XMB/PS5, чёрный фон с волнами, логотип кролика. Заменяет ванильный экран. */
public class FlrTitleScreen extends Screen {
    private record Item(String label, String desc, int icon, String btn, Supplier<Screen> target) {}

    private final List<Item> items = new ArrayList<>();
    private float[] grow = new float[0];
    private int[] hx = new int[0], hy = new int[0], hs = new int[0];
    private int sel;
    private long lastNs;
    private int playX, playY, playW, playH, gearX, gearY;

    public FlrTitleScreen() {
        super(Component.literal("FLR Visuals"));
    }

    @Override
    protected void init() {
        Minecraft mc = Minecraft.getInstance();
        items.clear();
        items.add(new Item("Singleplayer", "Your worlds. A quiet corner of an endless world.", 0, "Play", () -> new SelectWorldScreen(this)));
        items.add(new Item("Multiplayer", "Servers and friends", 1, "Join", () -> new JoinMultiplayerScreen(this)));
        items.add(new Item("Mods", "Installed mods", 2, "Browse", () -> new ModListScreen(this)));
        items.add(new Item("Options", "Game settings", 3, "Open", () -> new OptionsScreen(this, mc.options)));
        items.add(new Item("FLR Visuals", "Cosmetics, pets, sky and weather", -1, "Open", CosmeticsScreen::new));
        items.add(new Item("Quit game", "See you soon", 4, "Quit", () -> null));
        int n = items.size();
        if (grow.length != n) {
            grow = new float[n];
            hx = new int[n]; hy = new int[n]; hs = new int[n];
            sel = Math.min(sel, n - 1);
            grow[sel] = 1f;
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    /** Для геймпада и клавиатуры. */
    void move(int d) {
        sel = Math.floorMod(sel + d, items.size());
    }

    void activate() {
        Item it = items.get(sel);
        Minecraft mc = Minecraft.getInstance();
        if (it.icon() == 4) mc.stop();
        else mc.setScreen(it.target().get());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        int acc = Config.color() & 0xFFFFFF;
        Backdrop.draw(g, width, height);

        // шапка: логотип, название, часы, настройки
        Ui.logo(g, 14, 10, 28, 1f);
        Ui.bold(g, "FLR Visuals", 48, 12, 0xFFFFFFFF);
        Ui.text(g, "2.0", 48, 23, 0xFF7C82A8);
        gearX = width - 34; gearY = 10;
        boolean hg = Ui.in(mx, my, gearX, gearY, 22, 22);
        CosmeticsScreen.rrect(g, gearX, gearY, 22, 22, 11, hg ? 0x66FFFFFF : 0x33FFFFFF);
        Ui.icon(g, 3, gearX + 4, gearY + 4, 14, 0xFFFFFF, 1f);
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        Ui.text(g, time, gearX - 10 - Ui.w(time), 15, 0xCCFFFFFF);

        // ряд иконок
        int n = items.size();
        int cy = (height < 300 ? 100 : Math.max(86, (int) (height * 0.27f)) + 40);
        int x = Math.max(24, (int) (width * 0.06f)), tx = x;
        for (int i = 0; i < n; i++) {
            grow[i] += ((i == sel ? 1f : 0f) - grow[i]) * Math.min(1f, dt * 12f);
            int s = 52 + (int) (36 * grow[i]);
            hx[i] = x; hy[i] = cy - s / 2; hs[i] = s;
            boolean on = i == sel, hv = Ui.in(mx, my, x, hy[i], s, s);
            if (on) CosmeticsScreen.rrect(g, x - 5, hy[i] - 5, s + 10, s + 10, s / 4 + 5, 0x30000000 | acc);
            CosmeticsScreen.rrect(g, x - 1, hy[i] - 1, s + 2, s + 2, s / 4 + 1, on ? 0xB0000000 | acc : (hv ? 0x60FFFFFF : 0x30FFFFFF));
            CosmeticsScreen.rrect(g, x, hy[i], s, s, s / 4, on ? 0xF01A1D33 : 0xE80F1220);
            int gs = (int) (s * 0.56f), gx = x + (s - gs) / 2, gy = hy[i] + (s - gs) / 2;
            float ga = on ? 1f : (hv ? 0.9f : 0.62f);
            if (items.get(i).icon() < 0) Ui.logo(g, gx - 2, gy - 2, gs + 4, ga);
            else Ui.icon(g, items.get(i).icon(), gx, gy, gs, on ? 0xFFFFFF : 0xB8BEE6, ga);
            x += s + 14;
        }

        // подпись выбранного пункта и кнопка
        Item it = items.get(sel);
        int ty = cy + 52 + 10;
        Ui.scaled(g, Tr.tr(it.label()), tx, ty, 2f, 0xFFFFFFFF, true);
        Ui.text(g, Tr.tr(it.desc()), tx, ty + 26, 0xFFA8ADCB);
        String bl = Tr.tr(it.btn());
        playW = Math.max(100, Ui.w(bl) + 44); playH = 22; playX = tx; playY = ty + 46;
        Ui.pill(g, playX, playY, playW, playH, bl, Ui.in(mx, my, playX, playY, playW, playH), true, acc);

        // карточки
        int cardY = playY + playH + 16;
        if (cardY + 46 < height - 28) {
            String[][] cards = {{"Account", Minecraft.getInstance().getUser().getName()},
                    {"Theme", Tr.tr(Config.THEME_NAMES[Mth.clamp(Config.theme, 0, Config.THEME_NAMES.length - 1)])},
                    {"Version", "FLR 2.0 · NeoForge 1.21.1"}};
            int cx = tx;
            for (String[] c : cards) {
                int cw = Math.max(120, Ui.wb(c[1]) + 28);
                CosmeticsScreen.rrect(g, cx, cardY, cw, 44, 10, 0x22FFFFFF);
                Ui.text(g, Tr.tr(c[0]), cx + 12, cardY + 9, 0xFF8A90B4);
                Ui.bold(g, Ui.fit(c[1], cw - 24), cx + 12, cardY + 23, 0xFFFFFFFF);
                cx += cw + 10;
            }
        }

        // подсказки и копирайт
        int hxp = 24, hyp = height - 18;
        hxp = hint(g, hxp, hyp, "<  >", Tr.tr("Select"));
        hint(g, hxp + 10, hyp, "Enter", Tr.tr("Open"));
        String cp = "Minecraft © Mojang AB";
        Ui.text(g, cp, width - 12 - Ui.w(cp), height - 15, 0x66FFFFFF);
    }

    private int hint(GuiGraphics g, int x, int y, String key, String label) {
        int kw = Ui.w(key) + 10;
        CosmeticsScreen.rrect(g, x, y - 3, kw, 14, 5, 0x40FFFFFF);
        Ui.text(g, key, x + 5, y, 0xFFFFFFFF);
        Ui.text(g, label, x + kw + 6, y, 0xFFA8ADCB);
        return x + kw + 6 + Ui.w(label);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (b == 0) {
            if (Ui.in(mx, my, gearX, gearY, 22, 22)) {
                Minecraft mc = Minecraft.getInstance();
                mc.setScreen(new OptionsScreen(this, mc.options));
                return true;
            }
            for (int i = 0; i < items.size(); i++) {
                if (Ui.in(mx, my, hx[i], hy[i], hs[i], hs[i])) {
                    if (i == sel) activate();
                    else sel = i;
                    return true;
                }
            }
            if (Ui.in(mx, my, playX, playY, playW, playH)) {
                activate();
                return true;
            }
        }
        return super.mouseClicked(mx, my, b);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        move(sy > 0 ? -1 : 1);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 263 || key == 65) { move(-1); return true; }
        if (key == 262 || key == 68) { move(1); return true; }
        if (key == 257 || key == 335 || key == 32) { activate(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
