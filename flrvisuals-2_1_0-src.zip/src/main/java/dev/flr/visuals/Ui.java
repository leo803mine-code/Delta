package dev.flr.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;

/** Общий набор для собственного оформления: шрифт Carlito, логотип кролика, иконки и кнопки-«таблетки». */
final class Ui {
    static final ResourceLocation LOGO = ResourceLocation.fromNamespaceAndPath("flrvisuals", "textures/gui/logo.png");
    static final ResourceLocation ICONS = ResourceLocation.fromNamespaceAndPath("flrvisuals", "textures/gui/icons.png");
    private static final Style REG = Style.EMPTY.withFont(ResourceLocation.fromNamespaceAndPath("flrvisuals", "flr"));
    private static final Style BOLD = Style.EMPTY.withFont(ResourceLocation.fromNamespaceAndPath("flrvisuals", "flrb"));

    private Ui() {}

    static Font font() {
        return Minecraft.getInstance().font;
    }

    static Component c(String s) {
        return Component.literal(s).withStyle(REG);
    }

    static Component cb(String s) {
        return Component.literal(s).withStyle(BOLD);
    }

    static int w(String s) {
        return font().width(c(s));
    }

    static int wb(String s) {
        return font().width(cb(s));
    }

    static void text(GuiGraphics g, String s, int x, int y, int color, boolean shadow) {
        g.drawString(font(), c(s), x, y, color, shadow);
    }

    static void text(GuiGraphics g, String s, int x, int y, int color) {
        text(g, s, x, y, color, false);
    }

    static void bold(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(font(), cb(s), x, y, color, false);
    }

    static void center(GuiGraphics g, String s, int cx, int y, int color) {
        text(g, s, cx - w(s) / 2, y, color);
    }

    static void scaled(GuiGraphics g, String s, float x, float y, float sc, int color, boolean bold) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(sc, sc, 1f);
        g.drawString(font(), bold ? cb(s) : c(s), 0, 0, color, false);
        g.pose().popPose();
    }

    static String fit(String s, int maxW) {
        if (w(s) <= maxW) return s;
        String t = s;
        while (t.length() > 1 && w(t + "…") > maxW) t = t.substring(0, t.length() - 1);
        return t + "…";
    }

    /** rgb + прозрачность 0..1 -> ARGB (минимум 8, иначе шрифт считает цвет непрозрачным). */
    static int argb(int rgb, float a) {
        return (Math.max(8, Math.min(255, (int) (a * 255))) << 24) | (rgb & 0xFFFFFF);
    }

    static void logo(GuiGraphics g, int x, int y, int size, float alpha) {
        RenderSystem.enableBlend();
        g.setColor(1f, 1f, 1f, alpha);
        g.blit(LOGO, x, y, size, size, 0f, 0f, 256, 256, 256, 256);
        g.setColor(1f, 1f, 1f, 1f);
    }

    /** idx: 0 игрок, 1 игроки, 2 моды, 3 настройки, 4 выход, 5 шестерня, 6 глобус, 7 снежинка. */
    static void icon(GuiGraphics g, int idx, int x, int y, int size, int rgb, float alpha) {
        RenderSystem.enableBlend();
        g.setColor((rgb >> 16 & 255) / 255f, (rgb >> 8 & 255) / 255f, (rgb & 255) / 255f, alpha);
        g.blit(ICONS, x, y, size, size, idx * 128f, 0f, 128, 128, 1024, 128);
        g.setColor(1f, 1f, 1f, 1f);
    }

    static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Кнопка-«таблетка». primary = светлая заливка с тёмным текстом. */
    static void pill(GuiGraphics g, int x, int y, int w, int h, String label, boolean hover, boolean primary, int accent) {
        if (primary) {
            CosmeticsScreen.rrect(g, x, y, w, h, h / 2, hover ? 0xFFFFFFFF : 0xFFE6E8F2);
            text(g, label, x + (w - w(label)) / 2, y + (h - 8) / 2, 0xFF10121C);
        } else {
            CosmeticsScreen.rrect(g, x - 1, y - 1, w + 2, h + 2, h / 2 + 1, hover ? 0x90000000 | accent : 0x40FFFFFF);
            CosmeticsScreen.rrect(g, x, y, w, h, h / 2, hover ? 0xF0262A46 : 0xF0141728);
            text(g, label, x + (w - w(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF);
        }
    }
}
