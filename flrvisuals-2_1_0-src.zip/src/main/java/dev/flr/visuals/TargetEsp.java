package dev.flr.visuals;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Target ESP: красивый крутящийся прицел (новогодний стиль) на существе, на которое вы навели прицел. */
final class TargetEsp {
    private static final double RANGE = 32.0;
    private static LivingEntity target, shown;
    private static float alpha, sx, sy, sr;
    private static long lastNs;

    private TargetEsp() {}

    static void tick(Minecraft mc) {
        target = null;
        if (!Config.master || !Config.targetEsp || mc.player == null || mc.level == null || mc.screen != null) return;
        var pl = mc.player;
        Vec3 eye = pl.getEyePosition(), look = pl.getViewVector(1f), end = eye.add(look.scale(RANGE));
        AABB box = pl.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(pl, eye, end, box,
                e -> e instanceof LivingEntity && e != pl && !e.isSpectator() && e.isPickable(), RANGE * RANGE);
        if (hit != null && hit.getEntity() instanceof LivingEntity le) target = le;
    }

    private static void dot(GuiGraphics g, float x, float y, int size, int rgb, float a) {
        int al = Math.max(4, Math.min(255, (int) (a * 255)));
        CosmeticsScreen.rrect(g, Math.round(x - size / 2f), Math.round(y - size / 2f), size, size, size / 2, (al << 24) | rgb);
    }

    static void render(GuiGraphics g, float pt) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        alpha += ((target != null ? 1f : 0f) - alpha) * Math.min(1f, dt * 10f);
        boolean fresh = false;
        if (target != null) {
            if (shown != target) fresh = true;
            shown = target;
        }
        if (shown == null) return;
        if (target == null && alpha < 0.03f || !shown.isAlive()) { shown = null; return; }

        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 p = new Vec3(Mth.lerp(pt, shown.xo, shown.getX()), Mth.lerp(pt, shown.yo, shown.getY()) + shown.getBbHeight() * 0.5,
                Mth.lerp(pt, shown.zo, shown.getZ()));
        Vec3 d = p.subtract(cam.getPosition());
        Vector3f l = cam.getLeftVector(), u = cam.getUpVector(), f = cam.getLookVector();
        double z = d.x * f.x() + d.y * f.y() + d.z * f.z();
        if (z < 0.3) return;
        double xr = -(d.x * l.x() + d.y * l.y() + d.z * l.z()), yu = d.x * u.x() + d.y * u.y() + d.z * u.z();
        int W = g.guiWidth(), H = g.guiHeight();
        double tan = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        float tx = (float) (W / 2.0 + xr / (z * tan * W / (double) H) * (W / 2.0));
        float ty = (float) (H / 2.0 - yu / (z * tan) * (H / 2.0));
        float tr = Mth.clamp((float) (shown.getBbHeight() / (z * tan) * H / 2.0) * 0.6f * (float) Config.espSize, 16f, 90f);
        if (fresh || sr == 0f) { sx = tx; sy = ty; sr = tr; }
        float k = Math.min(1f, dt * 18f);
        sx += (tx - sx) * k; sy += (ty - sy) * k; sr += (tr - sr) * k;

        float t = (now / 1_000_000_000f) % 1000f;
        boolean xmas = Config.espStyle == 0;
        int c1 = xmas ? 0xE53A47 : (Config.color() & 0xFFFFFF), c2 = xmas ? 0xFFFFFF : 0xFFFFFF;
        float pulse = 1f + 0.05f * Mth.sin(t * 4f), r = sr * pulse;

        // тонкое статичное кольцо
        for (int i = 0; i < 28; i++) {
            double a = i * Math.PI * 2 / 28;
            dot(g, sx + (float) Math.cos(a) * r * 1.12f, sy + (float) Math.sin(a) * r * 1.12f, 2, c2, alpha * 0.28f);
        }
        // четыре крутящиеся дуги
        for (int arc = 0; arc < 4; arc++) {
            float base = t * 1.7f + arc * Mth.HALF_PI;
            int col = arc % 2 == 0 ? c1 : c2;
            for (int i = 0; i < 9; i++) {
                float ang = base + i * 0.085f;
                dot(g, sx + Mth.cos(ang) * r, sy + Mth.sin(ang) * r, i > 5 ? 3 : 4, col, alpha * (1f - i * 0.07f));
            }
        }
        // внутренние снежинки (плюсы), крутятся в обратную сторону
        for (int kx = 0; kx < 4; kx++) {
            float ang = -t * 1.2f + kx * Mth.HALF_PI;
            int cx = Math.round(sx + Mth.cos(ang) * r * 0.62f), cy = Math.round(sy + Mth.sin(ang) * r * 0.62f);
            int al = Math.max(4, (int) (alpha * 230)) << 24;
            g.fill(cx - 3, cy, cx + 4, cy + 1, al | c2);
            g.fill(cx, cy - 3, cx + 1, cy + 4, al | c2);
            g.fill(cx - 1, cy - 1, cx + 2, cy + 2, al | c1);
        }
        // центр: ромб
        float cr = 4f + Mth.sin(t * 5f);
        for (int kx = 0; kx < 4; kx++) {
            float ang = t * 2.4f + kx * Mth.HALF_PI;
            dot(g, sx + Mth.cos(ang) * cr, sy + Mth.sin(ang) * cr, 3, kx % 2 == 0 ? c1 : c2, alpha);
        }
        // имя и здоровье
        String s = shown.getDisplayName().getString() + "  " + String.format("%.1f", shown.getHealth()) + " HP";
        int w = Ui.w(s) + 14, x0 = Math.round(sx - w / 2f), y0 = Math.round(sy + r + 8);
        CosmeticsScreen.rrect(g, x0 - 1, y0 - 1, w + 2, 16, 8, (Math.max(4, (int) (alpha * 110)) << 24) | c1);
        CosmeticsScreen.rrect(g, x0, y0, w, 14, 7, (Math.max(4, (int) (alpha * 220)) << 24) | 0x11121B);
        Ui.text(g, s, x0 + 7, y0 + 3, (Math.max(8, (int) (alpha * 255)) << 24) | 0xFFFFFF, false);
    }
}
